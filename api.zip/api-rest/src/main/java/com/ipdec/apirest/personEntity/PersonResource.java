package com.ipdec.apirest.personEntity;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ipdec.apirest.personEntity.Person;
import com.ipdec.apirest.personEntity.PersonRepository;

import java.util.Optional;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.ArrayList;


@RestController
@RequestMapping(path="persons")
public class PersonResource {
	private PersonRepository personRepository;
	
	public PersonResource(PersonRepository personRepository) {
		super();
		this.personRepository = personRepository;
		//o que é o person repository e o que faz.
	}
	
	@PostMapping //o que é esse <Person> e o <optional<person>>
	public ResponseEntity<Person> save(@RequestBody Person person) {
		personRepository.save(person);
		return new ResponseEntity<>(person, HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Person>> getAll() {
		List<Person> persons = new ArrayList<>();
		persons = personRepository.findAll();
		return new ResponseEntity<>(persons, HttpStatus.OK);
	}
	
	@GetMapping(path="/{id}") //por que o get mapping não utiliza query params
	public ResponseEntity<Optional<Person>> getbyId(@PathVariable Integer id){
		Optional<Person> person;
		try {
			person = personRepository.findById(id);
			return new ResponseEntity<Optional<Person>>(person, HttpStatus.OK);
		}catch (NoSuchElementException nsee) {
			return new ResponseEntity<Optional<Person>>(HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping(value="/{id}") //por que aqui é value e o anterior é path???
	public ResponseEntity<Person> update(@PathVariable Integer id, @RequestBody Person newPerson){
		return personRepository.findById(id)
				.map(person -> {
					person.setName(newPerson.getName());
					person.setAge(newPerson.getAge());
					Person personoUpdated = personRepository.save(person);
					return ResponseEntity.ok().body(personoUpdated);
				}).orElse(ResponseEntity.notFound().build());
		
	}
	
	@DeleteMapping(path="/{id}")
	public ResponseEntity<Optional<Person>> deleteById(@PathVariable Integer id){
		try {
			personRepository.deleteById(id);
			return new ResponseEntity<Optional<Person>>(HttpStatus.OK);
		}catch (NoSuchElementException nsee) {
			return new ResponseEntity<Optional<Person>>(HttpStatus.NOT_FOUND);
		}
	}
	
}
